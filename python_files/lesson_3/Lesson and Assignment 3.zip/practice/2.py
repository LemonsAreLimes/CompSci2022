def isEven(n=None):
    if n==None: return None

    number = not n % 2
    return number
    

x = isEven(83476238487263464873)
print(x )
